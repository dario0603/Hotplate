/*------------------------------------------------------------------*/
/*                Reflow function Arduino library                   */
/*                          version 1.0.0                           */
/*                                                                  */
/*  all the default settings are set in degrees and seconds, if the */
/*  measure units you want to use are different just modify it      */
/*  with the set function                                           */
/*                                                                  */
/*------------------------------------------------------------------*/

#ifndef REFLOW_FUNCTION_h
#define REFLOW_FUNCTION_h

#define LIBRARY_VERSION	1.0.0

enum values{TIME, TEMP_I, TEMP_F, SLOPE, OFFSET};

class Reflow_function{

  //Private
  private:

  #define M_MAX 100             //maximum slope of each straight function
  #define TIME_MAX 100          //maximum time of reflow stationary function

  double m[4], q[4], time[4], temp[4];   //parameters for all the function
  double time_stop, time_0;              //time when the temperature is maximum

  //return the preheat function value according to the time passed
  double funct_Preheat(double time) const;

  //return the soak function value according to the time passed
  double funct_Soak(double time) const;

  //return the reflow function value according to the time passed
  double funct_Reflow(double time) const;
  double funct_Reflow_time_stop() const;

  //return the cooling function value according to the time passed
  double funct_Cooling(double time) const;

  //Public
  public:

  //Default constructor of the class Reflow_function
  Reflow_function();

  //Function to set the preheat parameters
  //return 0 if the operation is successful
  //return 1 if the operation return error
  bool set_Preheat_temp(double m, double temp_max, double offset);
  bool set_Preheat_time(double m, double delta_time, double offset);

  //Function to set the soak parameters
  //return 0 if the operation is successful
  //return 1 if the operation return error
  bool set_Soak_temp(double m, double temp_max);
  bool set_Soak_time(double delta_time, double temp_max);

  //Function to set the reflow parameters
  //return 0 if the operation is successful
  //return 1 if the operation return error
  bool set_Reflow_temp(double m, double temp_max);
  bool set_Reflow_time(double delta_time, double temp_max);

  //Function to set the time when the temperature
  //remains at the maximum value
  bool set_Reflow_rect(int t);

  //Function to set the cooling parameters
  //return 0 if the operation is successful
  //return 1 if the operation return error
  bool set_Cooling_temp(double m, double temp_min);
  bool set_Cooling_time(double delta_time, double temp_min);

  //Function to set the zero value for the time
  bool set_zero(double time);

  //Function that return the value of the reflow function
  //according to the time passed
  double value(double time, bool &exit) const;

  //Function that return all the main values of the preheat straight function
  double preheat_value(values val = TIME) const;

  //Function that return all the main values of the soak straight function
  double soak_value(values val = TIME) const;

  //Function that return all the main values of the reflow straight function
  double reflow_value(values val = TIME) const;

  //Function that return all the main values of the cooling straight function
  double cooling_value(values val = TIME) const;

};

#endif