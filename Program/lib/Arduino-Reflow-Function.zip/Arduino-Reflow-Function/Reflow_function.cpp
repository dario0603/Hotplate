/*------------------------------------------------------------------*/
/*                Reflow function Arduino library                   */
/*                          version 1.0.0                           */
/*                                                                  */
/*  all the default settings are set in degrees and seconds, if the */
/*  measure units you want to use are different just modify it      */
/*  with the set function                                           */
/*                                                                  */
/*------------------------------------------------------------------*/

#if ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

#include "Reflow_function.h"

//Default constructor of the class Reflow function
Reflow_function::Reflow_function(){

  set_Preheat_temp(2, 110, 20);
  set_Soak_time(75, 140);
  set_Reflow_time(30, 165);
  set_Reflow_rect(20);
  set_Cooling_temp(-4, 20);

}

//Public set functions
bool Reflow_function::set_Preheat_temp(double m, double temp_max, double offset){

  this -> m[0] = m;
  this -> time[0] = (temp_max - offset)/m;
  this -> q[0] = offset;
  this -> temp[0] = temp_max;

  if(temp[0] < 0)
    return true;
  return false;

}

bool Reflow_function::set_Preheat_time(double delta_time, double temp_max, double offset){

  this -> m[0] = (temp_max - offset)/delta_time;
  this -> time[0] = delta_time;
  this -> q[0] = offset;
  this -> temp[0] = temp_max;

  if(temp[0] < 0)
    return true;
  return false;

}

bool Reflow_function::set_Soak_temp(double m, double temp_max){
  
  this -> m[1] = m;
  this -> time[1] = (temp_max - temp[0])/m;
  this -> q[1] = temp_max - (m * (time[1] + time[0]));
  this -> temp[1] = temp_max;

  if(temp[1] < 0)
    return true;
  return false;

}

bool Reflow_function::set_Soak_time(double delta_time, double temp_max){

  this -> m[1] = (temp_max - temp[0])/delta_time;
  this -> time[1] = delta_time;
  this -> q[1] = temp[0] - (time[0] * this -> m[1]);
  this -> temp[1] = temp_max;

  if(temp[1] < 0)
    return true;
  return false;

}

bool Reflow_function::set_Reflow_temp(double m, double temp_max){

  this -> m[2] = m;
  this -> time[2] = (temp_max - temp[1])/m;
  this -> q[2] = temp_max - (m * (time[2] + time[1] + time[0]));
  this -> temp[2] = temp_max;

  if(temp[2] < 0)
    return true;
  return false;

}

bool Reflow_function::set_Reflow_time(double delta_time, double temp_max){

  this -> m[2] = (temp_max - temp[1])/delta_time;
  this -> time[2] = delta_time;
  this -> q[2] = temp[1] - ((time[0] + time[1]) * this -> m[2]);
  this -> temp[2] = temp_max;

  if(temp[2] < 0)
    return true;
  return false;

}

bool Reflow_function::set_Reflow_rect(int t){

  if(t < 0 || t > TIME_MAX)
    return true;

  time_stop = t;

  if(temp[2] < 0)
    return true;

  return false;

}

bool Reflow_function::set_Cooling_temp(double m, double temp_min){
  
  this -> m[3] = m;
  this -> time[3] = (temp_min - temp[2])/m;
  this -> q[3] = temp[2] - ((time[0] + time[1] + time[2] + time_stop) * m);
  this -> temp[3] = temp_min;

  if(temp[3] < 0)
    return true;
  return false;

}

bool Reflow_function::set_Cooling_time(double delta_time, double temp_min){

  this -> m[3] = (temp_min - this -> temp[2])/delta_time;
  this -> time[3] = delta_time;
  this -> q[3] = temp[2] - ((time[0] + time[1] + time[2] + time_stop) * this -> m[3]);
  this -> temp[3] = temp_min;

  if(temp[3] < 0)
    return true;
  return false;

}

bool Reflow_function::set_zero(double time_0){

  if(time_0 < 0)
    return true;

  this -> time_0 = time_0;
  return false;

}

//Public return value function
double Reflow_function::value(double time, bool &exit) const{

  double t = time - time_0;

  exit = false;

  if(t <= (this -> time[0]))
    return funct_Preheat(time);

  if(t <= (this -> time[1] + this -> time[0]))
    return funct_Soak(time);

  if(t <= (this -> time[2] + this -> time[1] + this -> time[0]))
    return funct_Reflow(time);

  if(t <= (this -> time_stop + this -> time[2] + this -> time[1] + this -> time[0]))
    return funct_Reflow_time_stop();

  if(t <= (this -> time[3] + this -> time_stop + this -> time[2] + this -> time[1] + this -> time[0]))
    return funct_Cooling(time);
  
  if(t > (this -> time[3] + this -> time_stop + this -> time[2] + this -> time[1] + this -> time[0]))
    exit = true;

  return 0;

}

//Public functions to return straight parameters
double Reflow_function::preheat_value(values val) const{

  switch(val){
    case TIME:
      return this -> time[0];
    case TEMP_I:
      return this -> q[0];
    case TEMP_F:
      return this -> temp[0];
    case SLOPE:
      return this -> m[0];
    default:
      return this -> q[0];
  }

}

double Reflow_function::soak_value(values val) const{

  switch(val){
    case TIME:
      return this -> time[1];
    case TEMP_I:
      return this -> temp[0];
    case TEMP_F:
      return this -> temp[1];
    case SLOPE:
      return this -> m[1];
    default:
      return this -> q[1];
  }

}

double Reflow_function::reflow_value(values val) const{

  switch(val){
    case TIME:
      return this -> time[2];
    case TEMP_I:
      return this -> temp[1];
    case TEMP_F:
      return this -> temp[2];
    case SLOPE:
      return this -> m[2];
    default:
      return this -> q[2];
  }

}

double Reflow_function::cooling_value(values val) const{

  switch(val){
    case TIME:
      return this -> time[3];
    case TEMP_I:
      return this -> temp[2];
    case TEMP_F:
      return this -> temp[3];
    case SLOPE:
      return this -> m[3];
    default:
      return this -> q[3];
  }
  
}

//Private functions
double Reflow_function::funct_Preheat(double time) const{
  return (m[0] * (time - time_0)) + q[0];
}

double Reflow_function::funct_Soak(double time) const{
  return (m[1] * (time - time_0)) + q[1];
}

double Reflow_function::funct_Reflow(double time) const{
  return (m[2] * (time - time_0)) + q[2];
}

double Reflow_function::funct_Reflow_time_stop() const{
  return this -> temp[2];
}

double Reflow_function::funct_Cooling(double time) const{
  return (m[3] * (time - time_0)) + q[3];
}